<?php
    require '../permisos.php';
    require '../conexion.php';
    
    $postdata=file_get_contents("php://input");
    print("k");
    print("ss"); 
    if(isset($postdata) && !empty($postdata)){
       
        $request=json_decode($postdata);
        $id=$request->estudiante;
        $idLibro=$request->libro;
       
       
 
       
        $sql="INSERT INTO `prestamo` (`id`,`idLibro`) 
        VALUES({$id}, {$idLibro})";
        print($sql);
        
        if(mysqli_query($conexion, $sql)){
            http_response_code(201);
        }else{
            http_response_code(422);
        } 
    
    }
?>  