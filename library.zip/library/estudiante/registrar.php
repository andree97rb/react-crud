<?php
    require '../permisos.php';
    require '../conexion.php';
    
    $postdata=file_get_contents("php://input");

    if(isset($postdata) && !empty($postdata)){
        $request=json_decode($postdata);
        $apellidoPaterno=$request->apPaterno;
        $apellidoMaterno=$request->apMaterno;        
        $nombre=$request->nombre;        
        $direccion=$request->direccion;  
        $carrera=$request->carrera;  
        $edad=$request->edad;  
       
 
       
        $sql="INSERT INTO `estudiante` (`apPaterno`, `apMaterno`, `nombre`,`direccion`,`carrera`,`edad`) 
        VALUES('{$apellidoPaterno}', '{$apellidoMaterno}','{$nombre}','{$direccion}','{$carrera}',{$edad})";
        
        if(mysqli_query($conexion, $sql)){
            http_response_code(201);
        }else{
            http_response_code(422);
        } 
    
    }
?>  