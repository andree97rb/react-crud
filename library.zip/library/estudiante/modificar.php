<?php
    require 'conexion.php';
    require 'permisos.php';

    $postdata=file_get_contents("php://input");
    if(isset($postdata) && !empty($postdata)){
        $request=json_decode($postdata);
        print_r($request);
        $id=$_GET['id'];
        $apPaterno=$request->apPaterno;
        $apMaterno=$request->apMaterno;
        $nombre=$request->nombre;
        $edad=$request->edad;
      
        $sql = "UPDATE `users` SET `apPaterno`='$apPaterno',`apMaterno`='$apMaterno',`nombre`='$nombre',`edad`=$edad
                WHERE `id`='{$id}' LIMIT 1";
        if(mysqli_query($conexion,$sql)){
            http_response_code(204);
        }else{
            return http_response_code(422);
        }
    }
?>