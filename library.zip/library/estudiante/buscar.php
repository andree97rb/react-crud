<?php    
    require 'permisos.php';
    require 'conexion.php';

    $cod=$_GET['id'];
    
    $sql = "SELECT * FROM `users` WHERE `id`='{$cod}' LIMIT 1";
    if($result=mysqli_query($conexion,$sql)){
        $fila=mysqli_fetch_assoc($result);
        echo $json=json_encode($fila);      
    }else{
        http_response_code(404);       
    }
?>