<?php
    require '../permisos.php';
    require '../conexion.php';    

    error_reporting(E_ERROR);
    $estudiantes =[];
    $sql="SELECT * FROM estudiante";
    if($result=mysqli_query($conexion,$sql)){
        $cr=0;
        while($fila=mysqli_fetch_assoc($result)){
            $estudiantes[$cr]['id']=$fila['id'];
            $estudiantes[$cr]['apPaterno']=$fila['apPaterno'];
            $estudiantes[$cr]['apMaterno']=$fila['apMaterno'];
            $estudiantes[$cr]['nombre']=$fila['nombre'];
            $estudiantes[$cr]['direccion']=$fila['direccion'];
            $estudiantes[$cr]['carrera']=$fila['carrera'];
            $estudiantes[$cr]['edad']=$fila['edad'];
            $cr++;
        }
        echo json_encode($estudiantes);
    } else{
        http_response_code(404);
    }
?>