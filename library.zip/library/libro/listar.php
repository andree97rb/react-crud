<?php
    require '../permisos.php';
    require '../conexion.php';    

    error_reporting(E_ERROR);
    $libros =[];
    $sql="SELECT * FROM libro";
    if($result=mysqli_query($conexion,$sql)){
        $cr=0;
        while($fila=mysqli_fetch_assoc($result)){
            $libros[$cr]['idLibro']=$fila['idLibro'];
            $libros[$cr]['titulo']=$fila['titulo'];
            $libros[$cr]['autor']=$fila['autor'];
            $libros[$cr]['editorial']=$fila['editorial'];
            $cr++;
        }
        echo json_encode($libros);
    } else{
        http_response_code(404);
    }
?>