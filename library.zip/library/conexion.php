<?php
    define('DB_HOST','localhost');
    define('DB_USER','root');
    define('DB_PASS','');
    define('DB_NAME','biblioteca');

    function conexion(){
        $con=mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

        if(mysqli_connect_errno($con)){ //Devuelve un código de error del último error de conexión
            die("Fallo de conexion: " . mysqli_connect_error()); //Devuelva la descripción del error del último error de conexión
        }
        mysqli_set_charset($con, "utf8"); //Establezca el conjunto de caracteres del cliente predeterminado
        return $con;
    }
    $conexion=conexion();
?>